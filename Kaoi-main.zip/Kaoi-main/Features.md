|Admin| usage | 
|------|--------| 
|Promote |  Makes user admin      | 
|Demote |Removes user adminship  |
| Remove | remove user |  

|Media| usage | 
|----|--------| 
|Spotify|  Downloads songs from Spotify| 
|YouTube video |Downloads video from YouTube| 
|YouTube audio| Downloads audio from YouTube|  |Utils| usage | |-----|--------| |Sticker|  Contains sticker related Coomands |  #### Send hi to see if the bot is on or not.

|General| usage |
|----|--------|
|Admins| Tags all the admins in a given group|
|Everyone| Tags all participants of the given group, usable only by admins|
|Help| Displays all the available commands of bot in the group|
|Mods| Displays the moderator's contact info|
|Profile| Displays a generated profile of the tagged/mentioned user|
|Xp| Views the tagged user's xp|

|Fun| usage|
|----|--------|
|Triggered| Tag a photo while commanding, given image would be triggered xD|
|Chess| Launches a game of chess straight in the group chat, YES THIS IS THE FUTURE! EMBRACE IT!|

|Misc| usage|
|----|--------|
|Delete| Deletes the quoted message, admin only feature|
|Hi| WELL|
|Void| View info :v|

|Moderation| usage|
|----|--------|
Activate| Activates certain bot features in a group chat|
|Deactivate| Deactivates certain bot features in a group chat|
|Promote| Promotes the tagged user as a admin on group chat, can be executed only if the one commanding is group admin|
|Demote| Demotes the tagged user as a standard participant from an admin if he's one. Can work only when commanding user is himself a group admin|
|Remove| Removes the tagged user from the group, can only work if the bot is an admin and the one commanding this too|

|Utils| usage|
|----|--------|
|Blur| Blurs the tagged image or the pfp of the user's commanding it|
|Sticker| Converts the given gif/image into a webp sticker|
|Subred| A random subreddit post based on the specified search would be fetched. (Sometimes nsfw posts can too be fetched so be careful)|

|Dev| usage|
|----|--------|
|Disable| Disables the specified bot command from being used in a group chat|
|Enable| Enables the specified bot command so that it can be used again in a group chat|
|Eval| Evaluates JavaScript|
|Ban| Bans the given user from using the bot|
|Unban| Unbans the given user, after this he/she can use the bot again|
